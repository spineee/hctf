let express             = require('express');
let app                 = express();
let fs                  = require('fs');
let btoa                = require('btoa');
let atob                = require('atob');
let mem;
let do_encrypt;
let do_decrypt;
let buffer;
let importObject = {
    env : {
        grow(needed) {
            end = mem.buffer.byteLength;
            mem.grow(needed);
            return end;
        },
        read_file(filename, addr , size) {
            let filenameBuffer = '';
            while (buffer[filename] != 0) {
                filenameBuffer += String.fromCharCode(buffer[filename++]);
            }
            content = fs.readFileSync(filenameBuffer);
            for (i=0; i < content.length;i++ && size--) {
                buffer[addr++] = content[i];
            }
        },
        read_data(addr) {
            for (i in importObject.data) {
                buffer[addr++] = importObject.data.charCodeAt(i);
            }
            return importObject.data.length;
        },
        read_pass(addr) {
            for (i in importObject.pass) {
                buffer[addr++] = importObject.pass.charCodeAt(i);
            }
        },
        read_random(addr) {
            random_s = "";
            for(i = 0;i < 16;i++) {
                random_s += String.fromCharCode(Math.floor(Math.random()*256));
            }
            for (i in random_s) {
                buffer[addr++] = random_s.charCodeAt(i);
            }
        }
    }
};

function encrypt(plainText, pass) {
    importObject.data = plainText;
    importObject.pass = pass;
    let wasmFile = fs.readFileSync('crypt.wasm');
    let r = WebAssembly.instantiate(wasmFile,importObject).then(
        (result) => {
            doEncrypt = result.instance.exports.encrypt;
            outSize = result.instance.exports.out_size;
            mem = result.instance.exports.memory;
            buffer = new Uint8Array(mem.buffer);
            pos = doEncrypt();
            buffer = new Uint8Array(mem.buffer);
            let arr = buffer.subarray(pos,pos+outSize());
            r = String.fromCharCode.apply(null,arr);
            return btoa(r);
    });
    return r;
}

function decrypt(data, pass) {
    importObject.data = data;
    importObject.pass = pass;
    let wasmFile = fs.readFileSync('crypt.wasm');
    let r = WebAssembly.instantiate(wasmFile,importObject).then(
        (result) => {
            doDecrypt = result.instance.exports.decrypt;
            outSize = result.instance.exports.out_size;
            mem = result.instance.exports.memory;
            buffer = new Uint8Array(mem.buffer);
            pos = doDecrypt();
            buffer = new Uint8Array(mem.buffer);
            let arr = buffer.subarray(pos,pos+outSize());
            r = String.fromCharCode.apply(null,arr);
            return r;
        });
    return r;
}

app.get("/", function(req,res) {
        res.sendfile('public/index.html');
    }
);


app.get('/encrypt', function(req,res) {
        let plainText = req.query['data'];
        let pass = req.query['pass'];
        plainText = atob(plainText)
        if(plainText.length >= 0x1000) {
            return res.send("data to long");
        }
        if(pass.length !== 8) {
            return res.send("please input 8 bytes password");
        }
        if(plainText === "" || pass === "") {
            return res.send("error");
        }
        encrypt(plainText, pass).then(
            (r) => {
                res.send(r);
            }
        );
    }
);

app.get('/decrypt', function(req,res) {
        data = req.query['data'];
        pass = req.query['pass'];
        data = atob(data);
        data = atob(data);
        if(data.length >= 0x1000) {
            return res.send("data to long");
        }
        if(pass.length !== 8) {
            return res.send("please input 8 bytes password");
        }
        if(data === "" || pass === "") {
            return res.send("error");
        }
        decrypt(data,pass).then(
            (r) => {
                res.send(r);
            }
        );
    }
);

app.listen(3000);